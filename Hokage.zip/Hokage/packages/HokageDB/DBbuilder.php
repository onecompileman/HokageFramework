<?php
    include('../../config/hokageDB.php');

    /*Database Query Helper*/
    class DBbuilder
    {
        public $query = null;
        protected $table = null;
        public $con;
        public $fieldsType;
        /*
         * Constructor Opens Connection
         *
         *  */
        public function __construct()
        {
            $con = mysqli_connect(host, username, password, hokagedb)
            or
            die(mysqli_error(mysqli_connect(host, username, password, hokagedb)));

            $this->table = ($this->table == null) ? get_class($this) : $this->table;

            $this->query = '';

            $this->getTableFieldsType();
        }

        /*
         * Count function
         *
         * */
        public function count()
        {
            if (empty($this->query)) {
                $results = mysqli_query($this->con, 'SELECT COUNT(*) FROM `$this->table`;');
                return ($results == false) ? null : mysqli_fetch_array($results)[0];
            } else {
                $results = mysqli_query($this->con, 'SELECT COUNT(*) FROM `$this->table` WHERE $this->query;');
                return ($results == false) ? null : mysqli_fetch_array($results)[0];
            }
        }

        /*
         * @returns Json rows
         * */
        public function get()
        {
            if (empty($this->query)) {
                $results = mysqli_query($this->con, 'SELECT * FROM `$this->table`;');
                return ($results == false) ? null : json_decode(json_encode(mysqli_fetch_assoc($results)));
            } else {
                $results = mysqli_query($this->con, 'SELECT * FROM `$this->table` WHERE $this->query;');
                return ($results == false) ? null : json_decode(json_encode(mysqli_fetch_assoc($results)));
            }
        }

        /*
         *@returns instance of this class
         *
         * */
        public function where($field,$value)
        {
            /*Instantiate query to blank*/
            $index = 0;
                if($this->fieldsType[$field] == 'int')
                {
                    $this->query .= (empty($this->query))? $field.'='.$value:' AND '.$field.'='.$value;
                }
                else
                {
                    $this->query .= (empty($this->query))? $field.'=\''.$value:'\' AND '.$field.'=\''.$value.'\'';
                }
            return $this;
        }

        public function getTableFieldsType()
        {
            $this->fieldsType = [];
            $results = mysqli_query($this->con,'SHOW FIELDS FROM `'.$this->table.'`;');

            foreach(mysqli_fetch_array($results) as $res)
            {
                if(strpos($res['Type'],'int') != false)
                {
                    $this->fieldsType[$res['Field']] = 'int';
                }
                else
                {
                    $this->fieldsType[$res['Field']] = 'string';
                }
            }
        }
    }
?>