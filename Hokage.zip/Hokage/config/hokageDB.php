<?php
/*
 * Base Config for Hokage's Database
 *
 * */

    /*Host Name*/
    define('host','localhost');

    /*Username*/
    define('username','localhost');

    /*Password*/
    define('password','localhost');

    /*HokageDB*/
    define('hokagedb','localhost');

?>
