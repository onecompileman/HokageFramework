<?php
    /*Loads Hokage DB*/
   spl_autoload_register(function($hokageClass)
   {
        require_once("../packages/HokageDB/{$hokageClass}");
   });

?>